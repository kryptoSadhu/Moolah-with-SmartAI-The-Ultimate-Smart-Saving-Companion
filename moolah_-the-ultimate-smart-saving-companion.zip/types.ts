export enum AppState {
  IDLE,
  SCANNING,
  LOADING,
  RESULTS,
  ERROR,
  SUBSCRIPTION_LOCKED,
}

export enum ResultTab {
  ONLINE = 'Online Prices',
  NEARBY = 'Nearby Stores',
}

export interface OnlinePrice {
  retailer: string;
  logo: string;
  price: number;
  url: string;
  offer?: string;
}

export interface LocalStore {
  name: string;
  price: number;
  address: string;
  distance: string;
  hours: string;
  lat: number;
  lng: number;
}

export interface Product {
  id: string;
  name: string;
  image: string;
  barcode: string;
  onlinePrices: OnlinePrice[];
  localStores: LocalStore[];
}