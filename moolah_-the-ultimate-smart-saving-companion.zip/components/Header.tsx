
import React from 'react';
import { CurrencyRupeeIcon } from './Icon';

interface HeaderProps {
    onLogoClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogoClick }) => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div 
          onClick={onLogoClick}
          className="flex items-center cursor-pointer"
        >
          <CurrencyRupeeIcon className="w-8 h-8 text-primary" />
          <h1 className="text-2xl font-bold text-gray-800 ml-2">Moolah</h1>
        </div>
      </div>
    </header>
  );
};

export default Header;
