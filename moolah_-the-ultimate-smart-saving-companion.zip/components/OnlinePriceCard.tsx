
import React from 'react';
import { OnlinePrice } from '../types';
import { ArrowTopRightOnSquareIcon, TagIcon } from './Icon';

interface OnlinePriceCardProps {
  item: OnlinePrice;
  isBest: boolean;
}

const OnlinePriceCard: React.FC<OnlinePriceCardProps> = ({ item, isBest }) => {
  return (
    <div className={`p-4 rounded-lg flex items-center gap-4 transition-all duration-300 ${isBest ? 'bg-green-100 border-2 border-primary' : 'bg-gray-50 border'}`}>
      <img src={item.logo} alt={`${item.retailer} logo`} className="w-16 h-16 object-contain" />
      <div className="flex-grow">
        <p className="font-semibold text-lg text-gray-800">{item.retailer}</p>
        {item.offer && (
            <div className="flex items-center text-sm text-secondary font-medium mt-1">
                <TagIcon className="w-4 h-4 mr-1"/>
                <span>{item.offer}</span>
            </div>
        )}
      </div>
      <div className="text-right">
        <p className={`text-2xl font-bold ${isBest ? 'text-primary' : 'text-gray-800'}`}>
          ₹{item.price.toFixed(2)}
        </p>
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-1 inline-flex items-center gap-1.5 px-4 py-1.5 bg-secondary text-white font-semibold rounded-md shadow-sm hover:bg-orange-600 transition-colors text-sm"
        >
          Buy Now
          <ArrowTopRightOnSquareIcon className="w-4 h-4" />
        </a>
      </div>
    </div>
  );
};

export default OnlinePriceCard;
