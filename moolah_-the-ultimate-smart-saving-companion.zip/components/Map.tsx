
import React from 'react';
import { LocalStore } from '../types';
import { MapPinIcon } from './Icon';

interface MapProps {
  stores: LocalStore[];
}

const Map: React.FC<MapProps> = ({ stores }) => {
  const sortedStores = [...stores].sort((a, b) => a.price - b.price);
  const bestPrice = sortedStores.length > 0 ? sortedStores[0].price : 0;

  return (
    <div className="mb-4">
      <h3 className="text-lg font-semibold text-gray-700 mb-2">Store Locations</h3>
      <div className="relative w-full h-56 bg-gray-200 rounded-lg overflow-hidden">
        {/* Placeholder map background */}
        <img 
          src="https://picsum.photos/seed/map/800/400" 
          alt="Map of nearby stores" 
          className="w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-black/10"></div>
        {/* Store Pins */}
        {stores.map((store) => {
          const isBest = store.price === bestPrice;
          const top = `${store.lat}%`;
          const left = `${store.lng}%`;

          return (
            <div
              key={store.name}
              className="absolute transform -translate-x-1/2 -translate-y-full"
              style={{ top, left }}
              title={`${store.name} - ₹${store.price}`}
            >
              <MapPinIcon className={`w-8 h-8 drop-shadow-lg ${isBest ? 'text-secondary' : 'text-primary'}`} />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Map;
