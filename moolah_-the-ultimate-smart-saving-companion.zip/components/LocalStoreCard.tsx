
import React from 'react';
import { LocalStore } from '../types';
import { MapPinIcon, ClockIcon } from './Icon';

interface LocalStoreCardProps {
  store: LocalStore;
  isBest: boolean;
}

const LocalStoreCard: React.FC<LocalStoreCardProps> = ({ store, isBest }) => {
  return (
    <div className={`p-4 rounded-lg flex items-start gap-4 transition-all duration-300 ${isBest ? 'bg-green-100 border-2 border-primary' : 'bg-gray-50 border'}`}>
      <div className="flex-shrink-0 mt-1">
        <MapPinIcon className={`w-6 h-6 ${isBest ? 'text-primary' : 'text-gray-500'}`} />
      </div>
      <div className="flex-grow">
        <div className="flex justify-between items-start">
            <div>
                <h3 className="font-semibold text-lg text-gray-800">{store.name}</h3>
                <p className="text-gray-600 text-sm">{store.address}</p>
            </div>
            <p className={`text-2xl font-bold flex-shrink-0 ml-4 ${isBest ? 'text-primary' : 'text-gray-800'}`}>
                ₹{store.price.toFixed(2)}
            </p>
        </div>
        <div className="mt-2 text-sm text-gray-500 flex items-center gap-4">
            <span className="font-bold">{store.distance} away</span>
            <span className="flex items-center gap-1.5">
                <ClockIcon className="w-4 h-4" />
                {store.hours}
            </span>
        </div>
      </div>
    </div>
  );
};

export default LocalStoreCard;
