
import React, { useEffect } from 'react';
import { CameraIcon, CheckCircleIcon } from './Icon';

interface ScannerProps {
  onScan: (barcode: string) => void;
  onCancel: () => void;
}

const Scanner: React.FC<ScannerProps> = ({ onScan, onCancel }) => {
  // We'll use a mock barcode for demonstration.
  // In a real app, a library like react-qr-scanner or the BarcodeDetector API would be used.
  const mockBarcode = '8901030789735'; // Parle-G Biscuit

  useEffect(() => {
    // In a real implementation, you would initialize the camera here.
    console.log("Camera view initialized. Ready to scan.");
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full p-4 bg-gray-900 rounded-2xl text-white">
      <h2 className="text-2xl font-bold mb-4">Scan Barcode</h2>
      <p className="text-gray-300 mb-6">Point your camera at a product's barcode.</p>
      
      {/* Camera Viewport Simulation */}
      <div className="w-full max-w-md h-64 bg-black rounded-lg flex items-center justify-center relative overflow-hidden">
        <CameraIcon className="w-24 h-24 text-gray-600" />
        {/* Animated scanning line */}
        <div className="absolute top-0 left-0 w-full h-1 bg-primary-light shadow-[0_0_10px_theme(colors.primary.light)] animate-scan"></div>
        <style>{`
          @keyframes scan {
            0% { transform: translateY(0); }
            100% { transform: translateY(256px); }
          }
          .animate-scan {
            animation: scan 2s linear infinite;
          }
        `}</style>
      </div>

      <div className="mt-8 text-center">
        <p className="text-gray-400 mb-4">For demonstration purposes:</p>
        <button
          onClick={() => onScan(mockBarcode)}
          className="w-full flex items-center justify-center gap-3 bg-primary hover:bg-primary-dark text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-colors duration-300"
        >
          <CheckCircleIcon className="w-6 h-6"/>
          Simulate Successful Scan
        </button>
        <button
          onClick={onCancel}
          className="mt-4 text-gray-300 hover:text-white transition-colors"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};

export default Scanner;
