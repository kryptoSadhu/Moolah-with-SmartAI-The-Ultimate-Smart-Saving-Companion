import React from 'react';
import { CrownIcon, XMarkIcon, CheckCircleIcon } from './Icon';

interface SubscriptionModalProps {
  onSubscribe: () => void;
  onClose: () => void;
}

const SubscriptionPlan: React.FC<{
  title: string;
  price: string;
  period: string;
  onSubscribe: () => void;
  bestValue?: boolean;
}> = ({ title, price, period, onSubscribe, bestValue = false }) => (
  <div className={`p-6 rounded-xl border-2 flex flex-col text-center transition-all duration-300 relative ${bestValue ? 'bg-primary-light/10 border-primary scale-105' : 'bg-gray-50 border-gray-200'}`}>
    {bestValue && (
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-secondary text-white text-xs font-bold px-3 py-1 rounded-full">
        BEST VALUE
      </div>
    )}
    <h3 className="text-xl font-bold text-gray-800">{title}</h3>
    <p className="mt-2 text-4xl font-extrabold text-gray-900">
      ₹{price}
      <span className="text-base font-medium text-gray-500">/{period}</span>
    </p>
    <button
      onClick={onSubscribe}
      className={`mt-6 w-full py-3 px-6 text-lg font-bold rounded-lg shadow-md transform hover:-translate-y-0.5 transition-all duration-200 ${bestValue ? 'bg-primary text-white hover:bg-primary-dark' : 'bg-white text-primary border-2 border-primary hover:bg-green-50'}`}
    >
      Subscribe Now
    </button>
  </div>
);

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ onSubscribe, onClose }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full p-4 md:p-8 bg-gray-100 relative">
      <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
        <XMarkIcon className="w-7 h-7" />
      </button>
      <CrownIcon className="w-16 h-16 text-secondary" />
      <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mt-4 text-center">Unlock Unlimited Scans!</h2>
      <p className="mt-2 text-gray-600 text-lg text-center">You've used all your free scans. Choose a plan to continue saving.</p>
      
      <div className="mt-8 w-full max-w-4xl grid grid-cols-1 md:grid-cols-3 gap-6">
        <SubscriptionPlan title="Monthly" price="24" period="mo" onSubscribe={onSubscribe} />
        <SubscriptionPlan title="Quarterly" price="49" period="3mo" onSubscribe={onSubscribe} />
        <SubscriptionPlan title="Yearly" price="199" period="yr" onSubscribe={onSubscribe} bestValue={true} />
      </div>

      <div className="mt-8 text-left max-w-md w-full space-y-2 text-gray-600">
        <div className="flex items-center gap-3">
          <CheckCircleIcon className="w-6 h-6 text-primary flex-shrink-0" />
          <span><span className="font-bold">Unlimited</span> barcode scans</span>
        </div>
        <div className="flex items-center gap-3">
          <CheckCircleIcon className="w-6 h-6 text-primary flex-shrink-0" />
          <span><span className="font-bold">Search</span> for products by name</span>
        </div>
        <div className="flex items-center gap-3">
          <CheckCircleIcon className="w-6 h-6 text-primary flex-shrink-0" />
          <span>Access to AI-powered <span className="font-bold">Smart Shopping Tips</span></span>
        </div>
         <div className="flex items-center gap-3">
          <CheckCircleIcon className="w-6 h-6 text-primary flex-shrink-0" />
          <span>Support future development of Moolah</span>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionModal;