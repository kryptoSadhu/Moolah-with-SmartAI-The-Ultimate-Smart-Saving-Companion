
import React, { useState, useMemo } from 'react';
import { Product, ResultTab, OnlinePrice, LocalStore } from '../types';
import OnlinePriceCard from './OnlinePriceCard';
import LocalStoreCard from './LocalStoreCard';
import Map from './Map';
import { getShoppingTip } from '../services/geminiService';
import { SparklesIcon, ArrowPathIcon } from './Icon';

interface ResultsViewProps {
  product: Product;
  onScanNew: () => void;
}

const ResultsView: React.FC<ResultsViewProps> = ({ product, onScanNew }) => {
  const [activeTab, setActiveTab] = useState<ResultTab>(ResultTab.ONLINE);
  const [geminiTip, setGeminiTip] = useState<string | null>(null);
  const [isTipLoading, setIsTipLoading] = useState(false);
  const [tipError, setTipError] = useState<string | null>(null);

  const bestOnlinePrice = useMemo(() => {
    return Math.min(...product.onlinePrices.map(p => p.price));
  }, [product.onlinePrices]);

  const bestLocalPrice = useMemo(() => {
    return Math.min(...product.localStores.map(p => p.price));
  }, [product.localStores]);

  const handleGetTip = async () => {
    setIsTipLoading(true);
    setTipError(null);
    setGeminiTip(null);
    try {
      const tip = await getShoppingTip(product, bestOnlinePrice, bestLocalPrice);
      setGeminiTip(tip);
    } catch (e) {
      setTipError('Could not fetch a smart tip at this moment.');
      console.error(e);
    } finally {
      setIsTipLoading(false);
    }
  };

  const TabButton: React.FC<{ tab: ResultTab }> = ({ tab }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`px-4 py-2 text-lg font-semibold rounded-t-lg transition-colors ${
        activeTab === tab 
          ? 'border-b-4 border-primary text-primary' 
          : 'text-gray-500 hover:text-gray-800'
      }`}
    >
      {tab}
    </button>
  );

  return (
    <div className="p-4 md:p-6 w-full">
      <div className="flex flex-col md:flex-row gap-6 border-b pb-6 mb-6">
        <img src={product.image} alt={product.name} className="w-32 h-32 md:w-40 md:h-40 object-cover rounded-lg shadow-md mx-auto md:mx-0" />
        <div className="flex-grow text-center md:text-left">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-800">{product.name}</h2>
          <p className="text-gray-500 mt-1">Barcode: {product.barcode}</p>
          <button
            onClick={onScanNew}
            className="mt-4 inline-flex items-center gap-2 text-primary hover:text-primary-dark font-semibold transition-colors"
          >
            <ArrowPathIcon className="w-5 h-5"/>
            Scan another product
          </button>
        </div>
      </div>

      {/* Gemini Smart Tip Section */}
      <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
        {!geminiTip && !isTipLoading && !tipError && (
            <button onClick={handleGetTip} className="flex items-center gap-2 text-primary font-bold">
                <SparklesIcon className="w-6 h-6"/>
                Get Smart Shopping Tip
            </button>
        )}
        {isTipLoading && (
            <div className="flex items-center gap-2 text-gray-600">
                <div className="w-5 h-5 border-2 border-gray-300 border-t-primary rounded-full animate-spin"></div>
                Thinking of a smart tip...
            </div>
        )}
        {tipError && <p className="text-red-600">{tipError}</p>}
        {geminiTip && (
            <div>
                <h4 className="font-bold text-lg text-primary flex items-center gap-2"><SparklesIcon className="w-5 h-5"/> Smart Tip</h4>
                <p className="text-gray-700 mt-1">{geminiTip}</p>
            </div>
        )}
      </div>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex gap-6" aria-label="Tabs">
          <TabButton tab={ResultTab.ONLINE} />
          <TabButton tab={ResultTab.NEARBY} />
        </nav>
      </div>

      <div className="py-6">
        {activeTab === ResultTab.ONLINE ? (
          <div className="space-y-4">
            {product.onlinePrices.sort((a,b) => a.price - b.price).map((item: OnlinePrice) => (
              <OnlinePriceCard key={item.retailer} item={item} isBest={item.price === bestOnlinePrice} />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            <Map stores={product.localStores} />
            {product.localStores.sort((a,b) => a.price - b.price).map((store: LocalStore) => (
              <LocalStoreCard key={store.name} store={store} isBest={store.price === bestLocalPrice} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ResultsView;
