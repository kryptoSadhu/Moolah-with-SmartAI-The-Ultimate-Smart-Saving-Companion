import { Product } from '../types';

const mockProducts: Record<string, Product> = {
  '8901030789735': {
    id: '1',
    name: 'Parle-G Gold Biscuits 1kg',
    image: 'https://picsum.photos/seed/parleg/400/400',
    barcode: '8901030789735',
    onlinePrices: [
      { retailer: 'Jiomart', logo: 'https://picsum.photos/seed/jiomart/200/200', price: 145.00, url: '#', offer: '5% off on Axis Bank cards' },
      { retailer: 'BigBasket', logo: 'https://picsum.photos/seed/bigbasket/200/200', price: 149.00, url: '#' },
      { retailer: 'Amazon', logo: 'https://picsum.photos/seed/amazon/200/200', price: 152.50, url: '#' },
      { retailer: 'Flipkart', logo: 'https://picsum.photos/seed/flipkart/200/200', price: 155.00, url: '#', offer: 'Flat 10 delivery' },
    ],
    localStores: [
      { name: 'Vijay Sales', price: 142.00, address: 'Andheri West, Mumbai', distance: '1.2km', hours: '10am - 9pm', lat: 20, lng: 30 },
      { name: 'D-Mart', price: 148.00, address: 'Lajpat Nagar, Delhi', distance: '3.5km', hours: '9am - 10pm', lat: 75, lng: 70 },
      { name: 'Annachi Kadai', price: 150.00, address: 'T. Nagar, Chennai', distance: '0.5km', hours: '8am - 11pm', lat: 50, lng: 50 },
    ],
  },
  '8901233019033': {
    id: '2',
    name: 'Tata Tea Gold 1kg',
    image: 'https://picsum.photos/seed/tatatea/400/400',
    barcode: '8901233019033',
    onlinePrices: [
      { retailer: 'BigBasket', logo: 'https://picsum.photos/seed/bigbasket/200/200', price: 610.00, url: '#', offer: 'Save 15%' },
      { retailer: 'Amazon', logo: 'https://picsum.photos/seed/amazon/200/200', price: 615.00, url: '#' },
      { retailer: 'Jiomart', logo: 'https://picsum.photos/seed/jiomart/200/200', price: 620.00, url: '#' },
    ],
    localStores: [
      { name: 'Reliance Fresh', price: 605.00, address: 'Koramangala, Bangalore', distance: '2.1km', hours: '9am - 9pm', lat: 30, lng: 80 },
      { name: 'Star Bazaar', price: 612.00, address: 'Bandra, Mumbai', distance: '4.0km', hours: '10am - 10pm', lat: 80, lng: 25 },
    ],
  },
  '8901058850020': {
    id: '3',
    name: 'Maggi 2-Minute Noodles Masala 70g',
    image: 'https://picsum.photos/seed/maggi/400/400',
    barcode: '8901058850020',
    onlinePrices: [
        { retailer: 'Blinkit', logo: 'https://picsum.photos/seed/blinkit/200/200', price: 14.00, url: '#' },
        { retailer: 'Zepto', logo: 'https://picsum.photos/seed/zepto/200/200', price: 14.00, url: '#' },
        { retailer: 'BigBasket', logo: 'https://picsum.photos/seed/bigbasket/200/200', price: 15.00, url: '#', offer: 'Buy 4 get 1 free' },
    ],
    localStores: [
        { name: 'Local Kirana Store', price: 13.50, address: 'Kandivali, Mumbai', distance: '0.2km', hours: '8am - 10pm', lat: 45, lng: 15 },
        { name: 'General Store', price: 14.00, address: 'Indiranagar, Bangalore', distance: '0.8km', hours: '9am - 9:30pm', lat: 60, lng: 90 },
    ],
  }
};

export const fetchProductByBarcode = (barcode: string): Promise<Product | null> => {
  console.log(`Searching for product with barcode: ${barcode}`);
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const product = mockProducts[barcode];
      if (product) {
        resolve(product);
      } else {
        // Resolve with null to indicate not found, which the UI handles
        resolve(null);
      }
    }, 1500); // Simulate network delay
  });
};

export const fetchProductByName = (name: string): Promise<Product | null> => {
  console.log(`Searching for product with name: ${name}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      const searchTerm = name.trim().toLowerCase();
      if (!searchTerm) {
        resolve(null);
        return;
      }
      const allProducts = Object.values(mockProducts);
      const foundProduct = allProducts.find(product => 
        product.name.toLowerCase().includes(searchTerm)
      );
      resolve(foundProduct || null);
    }, 1000); // Simulate network delay
  });
};