import { GoogleGenAI } from '@google/genai';
import { Product } from '../types';

// Ensure the API key is available in the environment variables
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This will not stop the app from running, but provides a clear console warning.
  // The UI will handle the error gracefully if the API call fails.
  console.warn("API_KEY for GoogleGenAI is not set. Smart Tip feature will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const getShoppingTip = async (
  product: Product,
  bestOnlinePrice: number,
  bestLocalPrice: number
): Promise<string> => {
    
  if(!API_KEY) {
      throw new Error("API key is not configured.");
  }
    
  const model = "gemini-2.5-flash";
  
  const prompt = `
    You are a friendly and savvy shopping assistant for consumers in India called "Moolah", The Ultimate Smart Saving Companion.
    A user is looking at the product "${product.name}".
    The best online price found is ₹${bestOnlinePrice}.
    The best price in a nearby physical store is ₹${bestLocalPrice}.

    Based on this information, provide one single, concise, and helpful shopping tip. The tip should be a single sentence.
    
    Examples of good tips:
    - "Since the local price is cheaper, you could save on delivery fees by buying it nearby!"
    - "Consider buying online to take advantage of credit card offers that might not be available locally."
    - "This is a popular item; buying it online might offer you subscription options for regular delivery."
    - "Given the small price difference, buying locally gives you the product instantly without any wait."

    Do not greet the user. Do not repeat the prices. Go straight to the tip.
  `;

  try {
    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
    });
    const text = response.text;
    
    if (!text) {
        throw new Error("Received an empty response from the AI.");
    }
    
    return text.trim();
  } catch (error) {
    console.error("Error fetching shopping tip from Gemini:", error);
    throw new Error("Failed to generate a smart tip. The AI service may be temporarily unavailable.");
  }
};