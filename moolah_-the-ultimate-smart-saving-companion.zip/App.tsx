import React, { useState, useCallback, useEffect } from 'react';
import { AppState, Product } from './types';
import Header from './components/Header';
import Scanner from './components/Scanner';
import ResultsView from './components/ResultsView';
import { fetchProductByBarcode, fetchProductByName } from './services/productService';
import Loader from './components/Loader';
import { CurrencyRupeeIcon, MagnifyingGlassIcon, QrCodeIcon, LockClosedIcon, CrownIcon } from './components/Icon';
import SubscriptionModal from './components/SubscriptionModal';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [product, setProduct] = useState<Product | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scanCount, setScanCount] = useState<number>(0);
  const [isSubscribed, setIsSubscribed] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [loaderMessage, setLoaderMessage] = useState<string>('');

  const FREE_SCAN_LIMIT = 20;

  useEffect(() => {
    const savedCount = localStorage.getItem('moolahScanCount');
    setScanCount(savedCount ? parseInt(savedCount, 10) : 0);
    const savedSubscription = localStorage.getItem('moolahIsSubscribed') === 'true';
    setIsSubscribed(savedSubscription);
  }, []);

  const handleAttemptScan = () => {
    if (!isSubscribed && scanCount >= FREE_SCAN_LIMIT) {
      setAppState(AppState.SUBSCRIPTION_LOCKED);
    } else {
      setAppState(AppState.SCANNING);
    }
  };

  const handleScan = useCallback(async (barcode: string) => {
    if (!isSubscribed) {
      const newCount = scanCount + 1;
      setScanCount(newCount);
      localStorage.setItem('moolahScanCount', newCount.toString());
    }

    setLoaderMessage('Finding the best deals for you...');
    setAppState(AppState.LOADING);
    setError(null);
    try {
      const productData = await fetchProductByBarcode(barcode);
      if (productData) {
        setProduct(productData);
        setAppState(AppState.RESULTS);
      } else {
        throw new Error("Product not found. Please try a different barcode.");
      }
    } catch (e) {
      setError((e as Error).message);
      setAppState(AppState.ERROR);
    }
  }, [scanCount, isSubscribed]);
  
  const handleSearch = useCallback(async (query: string) => {
    if (!query.trim() || !isSubscribed) return;

    setLoaderMessage(`Searching for "${query}"...`);
    setAppState(AppState.LOADING);
    setError(null);
    try {
        const productData = await fetchProductByName(query);
        if (productData) {
            setProduct(productData);
            setAppState(AppState.RESULTS);
        } else {
            throw new Error(`No product found matching "${query}". Try a different name.`);
        }
    } catch (e) {
        setError((e as Error).message);
        setAppState(AppState.ERROR);
    }
  }, [isSubscribed]);

  const handleReset = useCallback(() => {
    setProduct(null);
    setError(null);
    setSearchQuery('');
    setAppState(AppState.IDLE);
  }, []);

  const handleSubscribe = () => {
    setIsSubscribed(true);
    localStorage.setItem('moolahIsSubscribed', 'true');
    // The scan count is no longer relevant for a subscribed user
    localStorage.setItem('moolahScanCount', '0');
    setScanCount(0);
    alert("Thank you for subscribing! You now have unlimited scans and product search.");
    setAppState(AppState.IDLE);
  };

  const renderContent = () => {
    switch (appState) {
      case AppState.SCANNING:
        return <Scanner onScan={handleScan} onCancel={handleReset} />;
      case AppState.LOADING:
        return <Loader message={loaderMessage} />;
      case AppState.RESULTS:
        return product ? <ResultsView product={product} onScanNew={handleReset} /> : null;
      case AppState.SUBSCRIPTION_LOCKED:
        return <SubscriptionModal onSubscribe={handleSubscribe} onClose={handleReset} />;
      case AppState.ERROR:
        return (
          <div className="text-center p-8">
            <h2 className="text-xl font-semibold text-red-600 mb-4">Oops! Something went wrong.</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <button
              onClick={handleReset}
              className="px-6 py-2 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary-dark transition-colors"
            >
              Try Again
            </button>
          </div>
        );
      case AppState.IDLE:
      default:
        const scansRemaining = Math.max(0, FREE_SCAN_LIMIT - scanCount);
        return (
          <div className="flex flex-col items-center justify-center h-full p-4 text-center">
             <div className="flex items-center text-4xl md:text-5xl font-bold text-gray-800 mb-2">
                <CurrencyRupeeIcon className="w-10 h-10 md:w-12 md:h-12 text-primary" />
                <span className="ml-2">Moolah</span>
            </div>
            <p className="text-lg text-gray-600 mb-2">The Ultimate Smart Saving Companion</p>
            <p className="text-sm text-gray-500 mb-8">For Mumbai, Delhi, Bangalore & Chennai</p>
            <div className="space-y-4 w-full max-w-sm">
                <button
                  onClick={handleAttemptScan}
                  className="w-full flex items-center justify-center gap-3 text-lg bg-primary text-white font-bold py-4 px-6 rounded-xl shadow-lg hover:bg-primary-dark transform hover:-translate-y-1 transition-all duration-300"
                >
                  <QrCodeIcon className="w-7 h-7" />
                  Scan a Product Barcode
                </button>
                <form 
                  onSubmit={(e) => { e.preventDefault(); handleSearch(searchQuery); }} 
                  className="relative flex items-center text-gray-400 group"
                >
                    <div className="absolute left-4 z-10">
                        {isSubscribed ? <MagnifyingGlassIcon className="w-5 h-5 text-gray-500"/> : <LockClosedIcon className="w-5 h-5 text-gray-500"/>}
                    </div>
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder={isSubscribed ? "Search product by name" : "Subscribe to search by name"}
                        disabled={!isSubscribed}
                        className={`w-full border rounded-xl py-4 pl-12 pr-14 text-gray-800 transition-colors duration-300 ${
                            isSubscribed 
                            ? 'bg-white border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary' 
                            : 'bg-gray-200 border-gray-300 text-gray-500 cursor-not-allowed'
                        }`}
                        aria-label={isSubscribed ? "Search product by name" : "Search by name (subscription required)"}
                    />
                    {isSubscribed && (
                      <button 
                        type="submit" 
                        aria-label="Submit Search"
                        className="absolute right-2 bg-primary text-white rounded-lg p-2 hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary-light focus:ring-offset-2 transition-all"
                      >
                          <MagnifyingGlassIcon className="w-5 h-5"/>
                      </button>
                    )}
                </form>
            </div>
            <div className="mt-8 text-center">
                {isSubscribed ? (
                    <p className="text-primary font-semibold flex items-center justify-center gap-2">
                        <CrownIcon className="w-6 h-6" /> Premium Member
                    </p>
                ) : scansRemaining > 0 ? (
                    <p className="text-primary font-semibold">
                        You have {scansRemaining} free scans remaining.
                    </p>
                ) : (
                    <p className="text-red-500 font-semibold">
                        You've used all your free scans.
                    </p>
                )}
                <p className="mt-2 text-sm text-gray-500 px-4">
                  {isSubscribed ? 'Enjoy unlimited scans and product search!' : 'Subscribe for unlimited features!'}
                </p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans flex flex-col">
      <Header onLogoClick={handleReset}/>
      <main className="flex-grow flex flex-col items-center justify-center container mx-auto px-4 py-6">
        <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl min-h-[600px] flex flex-col overflow-hidden">
            {renderContent()}
        </div>
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} Moolah. Save smartly.</p>
      </footer>
    </div>
  );
};

export default App;